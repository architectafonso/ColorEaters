package com.empire_of_science.joao.coloreaters2;

/**
 * Created by João on 07/12/2016.
 * 
 */

enum Colors {
    Green,
    Blue,
    Red,
    Yellow,
    White
}
