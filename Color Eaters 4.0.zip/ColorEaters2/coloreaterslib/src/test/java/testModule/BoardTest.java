package testModule;

import org.junit.Test;

/**
 * Created by João on 07/12/2016.
 */

public class BoardTest {

    @Test
    public void BoardCreationTest() {

    }
}
