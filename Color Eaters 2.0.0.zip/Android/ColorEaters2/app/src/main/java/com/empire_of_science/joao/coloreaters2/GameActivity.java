package com.empire_of_science.joao.coloreaters2;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

public class GameActivity extends Activity {

    /**
     * The Game View acquired at onCreate().
     */
    GameView gameView;

    /**
     * The level that will be played.
     */
    public int level;

    /**
     * The level package that the level belongs to.
     */
    public int levelPackage;


    /**
     * Gets the gameView and sets the game pieces, the level, number of moves, and also sets
     * the animation and sound on or off.
     *
     * Has to request ad, and set the number of moves and level on the respective views.
     *
     * @param savedInstanceState Game saved from rotation.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        // Gets the GameView.
        gameView = (GameView) findViewById(R.id.gameV);

        // Sets the ad banner.
        AdView mAdView = (AdView) findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);


        // If it's getting the level first time, gets level and level package from Bundle and sets
        // pieces and number of moves on the GameView.
        if(savedInstanceState == null){
            level = getIntent().getExtras().getInt("level");
            levelPackage = getIntent().getExtras().getInt("levelPackage");
            gameView.Pieces = Levels.getLevel(levelPackage, level);
            gameView.movesLeft = (new Levels()).getNumberOfMoves(levelPackage, level);
            gameView.invalidate();
        }
        else
        {
            // If it is getting an ongoing game, sets the pieces from the arrays with their data
            // on the bundle, and also the level, level package and number of moves left.
            int[] xArray = savedInstanceState.getIntArray("xArray");
            int[] yArray = savedInstanceState.getIntArray("yArray");
            int[] colorArray = savedInstanceState.getIntArray("colorArray");
            boolean[] isEaterArray = savedInstanceState.getBooleanArray("isEaterArray");

            int numberOfPieces = xArray.length;
            for(int index = 0; index < numberOfPieces; index++){
                gameView.Pieces.add(new BoardPiece(xArray[index], yArray[index], colorArray[index], isEaterArray[index]));
            }

            gameView.movesLeft = savedInstanceState.getInt("movesLeft");
            level = savedInstanceState.getInt("level");
            levelPackage = savedInstanceState.getInt("levelPackage");
            gameView.invalidate();
        }

        // Sets the number of moves to display. Actual ID depends on the layout, could be
        // moves_left or moves_left_large_3, because in tablets in landscape the number of moves
        // uses 3 text views.
        TextView text = (TextView)findViewById(R.id.moves_left);           //gets text view
        if (text == null){
            ((TextView)findViewById(R.id.moves_left_large_3)).setText("" + gameView.movesLeft);
        }else {
            String s = getResources().getString(R.string.moves_left);
            text.setText(s + gameView.movesLeft);
        }

        // Sets the level text view.
        TextView lev = (TextView)findViewById(R.id.level);
        String s = getResources().getString(R.string.level_indicator);
        lev.setText(s + " " + levelPackage + "/" + level);

        // Sets the animation and sound on or off.
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(this);
        if (!pref.contains("sound")) pref.edit().putBoolean("sound", true).commit();
        if (!pref.contains("animation"))pref.edit().putBoolean("animation", true).commit();
        gameView.soundOn = pref.getBoolean("sound", true);
        gameView.animationOn = pref.getBoolean("animation", true);
    }

    /**
     * This method has to save the state of the game for when the device is rotated.
     *
     * If it was in the middle of an animation, has to commit the changes of the animation
     * before starting to save the game pieces. Also tests for the end of the game.
     *
     * It saves on the bundle:
     * 1: List of game pieces, with an array for each one of this fields:
     * 1.1: boardX;
     * 1.2: boardY;             The arrays have the name of the fields followed by 'Array'
     * 1.3: color;
     * 1.4: isEater;
     *
     * 2: GameView fields that allow reconstructions of the exact moment of the game:
     * 2.1: numberOfMoves;
     * 2.2: level;
     * 2.3: levelPackage.
     *
     * @param outState The bundle caring the game state info.
     */
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        // If was just about to win or lose, changes to the adequate activity.
        if (gameView.gonnaLose) lose();
        if (gameView.gonnaWin) win();

        // Ensures that the animations are completed.
        // This means to guarantee that pieces to delete are deleted, so that they don't make it
        // to the bundle. The game view's onTouch already put the game pieces' boardX and boardY
        // on their destination and the float coordinates are going to be set when they are recreated,
        // so they don't matter here.
        if (gameView.needDelete){
            gameView.removeDeletedPieces();
        }

        // Creates the arrays carrying information of every BoardPiece.
        int count = gameView.Pieces.size();
        int[] xArray = new int[count];
        int[] yArray = new int[count];
        int[] colorArray = new int[count];
        boolean[] isEaterArray = new boolean[count];

        // Puts the information on the arrays.
        count = 0;
        for(BoardPiece piece : gameView.Pieces) {
            xArray[count] = piece.boardX;
            yArray[count] = piece.boardY;
            colorArray[count] = piece.pieceColor;
            isEaterArray[count] = piece.isEater;
            count++;
        }

        // Puts pieces data on the bundle.
        outState.putIntArray("xArray", xArray);
        outState.putIntArray("yArray", yArray);
        outState.putIntArray("colorArray", colorArray);
        outState.putBooleanArray("isEaterArray", isEaterArray);

        // Gets and puts game data on the bundle.
        outState.putInt("level", level);
        outState.putInt("levelPackage", levelPackage);
        outState.putInt("movesLeft", gameView.movesLeft);
    }


    /**
     * If back button is pressed, goes to the level selection menu for the appropriate package.
     * The intent will have "levelPackage".
     */
    @Override
    public void onBackPressed(){
        Intent intent = new Intent(this, LevelMenuActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("levelPackage", levelPackage);
        startActivity(intent);
    }


    /**
     * Called by the view when the user wins the game.
     * Also called from onSaveInstanceState.
     */
    public void win(){
        gameView.gonnaWin = false;                             // Necessary to avoid calling twice when screen rotates.
        Intent intent = new Intent(this, WinActivity.class);
        intent.putExtra("level", level);
        intent.putExtra("levelPackage", levelPackage);
        startActivity(intent);
    }

    /**
     * Called by the view when the user loses the game.
     * Also called from onSaveInstanceState.
     */
    public void lose(){
        gameView.gonnaLose = false;                             // Necessary to avoid calling twice when screen rotates.
        Intent intent = new Intent(this, LoseActivity.class);
        intent.putExtra("level", level);
        intent.putExtra("levelPackage", levelPackage);
        startActivity(intent);
    }


    /**
     * Sets the number of moves on the screen.
     * @param moves moves left.
     */
    public void changeMoves(int moves){
        TextView text = (TextView)findViewById(R.id.moves_left);
        if (text == null){
            ((TextView)findViewById(R.id.moves_left_large_3)).setText( "" + moves);
        }else {
            String s = getResources().getString(R.string.moves_left);
            text.setText(s + moves);
        }
    }

    /**
     * Called by Restart button.
     *
     * @param view pressed button.
     */
    public void restart(View view){
        Intent intent = getIntent();
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        finish();
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_game, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        return (id == R.id.action_settings)||super.onOptionsItemSelected(item);
    }
}