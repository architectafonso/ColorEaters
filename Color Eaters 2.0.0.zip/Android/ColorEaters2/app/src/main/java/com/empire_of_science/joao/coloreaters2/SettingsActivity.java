package com.empire_of_science.joao.coloreaters2;

import android.app.Activity;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;

import java.util.prefs.Preferences;

public class SettingsActivity extends AppCompatActivity {

    public boolean animationOn;
    public boolean soundOn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);


        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(this);
        if (!pref.contains("sound")){
            pref.edit().putBoolean("sound", true).apply();
            soundOn = true;
        }  else {
            if (pref.getBoolean("sound", true)){
                soundOn = true;
            }else{
                soundOn = false;
            }
        }
        if (!pref.contains("animation")){
            pref.edit().putBoolean("animation", true).apply();
            animationOn = true;
        }  else {
            if (pref.getBoolean("animation", true)){
                animationOn = true;
            }else{
                animationOn = false;
            }
        }
        
        // Sets the buttons and texts.
        if (soundOn){
            ((TextView)findViewById(R.id.sound)).setText(R.string.sound_on);
            ((Button)findViewById(R.id.sound_button)).setText(R.string.turn_sound_off);
        } else {
            ((TextView)findViewById(R.id.sound)).setText(R.string.sound_off);
            ((Button)findViewById(R.id.sound_button)).setText(R.string.turn_sound_on);
        }
        if (animationOn){
            ((TextView)findViewById(R.id.animation)).setText(R.string.animation_on);
            ((Button)findViewById(R.id.animation_button)).setText(R.string.turn_animation_off);
        } else {
            ((TextView)findViewById(R.id.animation)).setText(R.string.animation_off);
            ((Button)findViewById(R.id.animation_button)).setText(R.string.turn_animation_on);
        }
        
    }

    public void setSound(View view){
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(this);
        if (soundOn){
            soundOn = false;
            ((TextView)findViewById(R.id.sound)).setText(R.string.sound_off);
            ((Button)findViewById(R.id.sound_button)).setText(R.string.turn_sound_on);
            pref.edit().putBoolean("sound", false).commit();
        } else {
            soundOn = true;
            ((TextView)findViewById(R.id.sound)).setText(R.string.sound_on);
            ((Button)findViewById(R.id.sound_button)).setText(R.string.turn_sound_off);
            pref.edit().putBoolean("sound", true).commit();
        }
    }

    public void setAnimation(View view){
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(this);
        if (animationOn){
            animationOn = false;
            ((TextView)findViewById(R.id.animation)).setText(R.string.animation_off);
            ((Button)findViewById(R.id.animation_button)).setText(R.string.turn_animation_on);
            pref.edit().putBoolean("animation", false).commit();
        }else {
            animationOn = true;
            ((TextView)findViewById(R.id.animation)).setText(R.string.animation_on);
            ((Button)findViewById(R.id.animation_button)).setText(R.string.turn_animation_off);
            pref.edit().putBoolean("animation", true).commit();
        }
    }
}
