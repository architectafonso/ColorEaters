package com.empire_of_science.joao.coloreaters2;

/**
 * A game piece used by the GameView to render the game.
 * Created by João on 14/08/2015.
 *
 */
public class BoardPiece {

    /**
     * Board x coordinate for the board cell the piece is in.
     * Will be a value between 0 and 5.
     */
    public int boardX;

    /**
     * Board y coordinate for the board cell the piece is in.
     * Will be a value between 0 and 5.
     */
    public int boardY;

    /**
     * X coordinate for the precise position of the piece in the view.
     * Used because of animations. Will be a value between 0 and 100.
     */
    public float floatX;

    /**
     * Y coordinate for the precise position of the piece in the view.
     * Used because of animations. Will be a value between 0 and 100.
     */
    public float floatY;

    /**
     * Set true during a test to check for pieces to be eaten.
     * If it's set true, this piece will be deleted when GameView.removeDeletedPieces.
     */
    public boolean toDelete;

    /**
     * If true, this piece is an eater and not a cake.
     */
    public boolean isEater;

    /**
     * Color of this piece. Currently allowed Color.BLUE, Color.GREEN, Color.WHITE,
     * Color.RED and Color.YELLOW.
     */
    public int pieceColor;

    /**
     * Used during test that checks pieces to eat. It is set true when this piece,
     * if set doDelete = true, has already checked the pieces above, below and to the sides
     * to see if they should be set to be eaten.
     */
    public boolean wasTested;

    /**
     * Used first to contain the destiny of the piece in the eat animation as intermediate result,
     * and then the value by which the position must be incremented in each frame.
     */
    public float destinyX, destinyY;

    /**
     * Points to teh eater of this piece, the one that tested this one as being to delete.
     * The reason why there's a reference to the eater first instead of getting the eater's position
     * is that the eater might move during move or swap animation, and then the pieces eaten by it
     * would move to a cell that's empty or with another piece.
     */
    public BoardPiece eater;


    /**
     * Constructor.
     *
     * @param board_x Cell x coordinate.
     * @param board_y Cell y coordinate.
     * @param piece_color Piece's color (green, red, yellow, white and blue).
     * @param is_eater True if eater and false if cake.
     */
    public BoardPiece(int board_x, int board_y, int piece_color, boolean is_eater){
        boardX = board_x;
        boardY = board_y;
        floatX = (100F/6F)*(float)board_x;
        floatY = (100F/6F)*(float)board_y;
        pieceColor = piece_color;
        isEater = is_eater;
    }

    /**
     * Makes sure the canvas float coordinates are set in accordance with board position.
     * This allows to make sure that the position is the one of the cell the piece is in after the
     * animations.
     * The float coordinates are set with a value between 0 and 100 and during GameView's onDraw
     * that is converted to the actual canvas coordinates.
     */
    public void stick(){
        floatX = (100F/6F)*(float)boardX;
        floatY = (100F/6F)*(float)boardY;
    }



}
