package com.empire_of_science.joao.coloreaters2;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.media.AudioManager;
import android.media.SoundPool;
import android.support.annotation.NonNull;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;


public class GameView extends View {

    /**
     * Set by the Activity's onCreate method according to the current user settings.
     */
    boolean soundOn, animationOn;

    /**
     * Set true when touch event detects that the game should end, the ending isn't immediate
     * so that the pieces animations can execute.
     */
    boolean gonnaWin = false, gonnaLose = false;

    /**
     * True if there is a selected piece.
     */
    public boolean hasSelected = false;

    /**
     * Cell coordinates of the selected piece.
     */
    public int selectedX, selectedY;

    /**
     * The context activity.
     * Allows calling it to end the game and change the number of moves.
     */
    public GameActivity activity;

    /**
     * Number of allowed moves remaining.
     */
    public int movesLeft;


    /**
     * List of the game pieces currently present on the board.
     */
    public List<BoardPiece> Pieces = new ArrayList<>();

    /**
     * Variation in position of pieces during move or swap animations, as set by the touch event.
     * If it's a move animation only piece1 ones are used.
     */
    float piece1XMovement, piece1YMovement, piece2XMovement, piece2YMovement;

    /**
     * The pieces to move or swap as set by the touch event. If there's only one piece to move to
     * an empty cell, only piece 1 is used.
     */
    BoardPiece piece1, piece2;

    /**
     * True if pieces are currently swapping.
     * Is set true by onTouch() if it verifies that a swap is necessary.
     */
    boolean inSwapping = false;

    /**
     * True if one piece is currently moving to an empty cell.
     * Is set true by onTouch() if it verifies that a move is necessary.
     */
    boolean inMove = false;

    /**
     * True it is eating.
     * It is set true by onDraw() if it is the last frame of an move or swap animation and the
     * needDelete is set true.
     */
    boolean inEating = false;

    /**
     * True if cake will be eaten after finishing of move or swap animation.
     * It is set false by onDraw after the eating.
     */
    boolean needDelete = false;

    /**
     * Current frame of an animation.
     */
    int frame;


    /**
     * SoundPool for the sound effects.
     */
    SoundPool soundPool;
    /**
     * Variables that will carry the id of each sound track.
     */
    int eatSound = 0, movingSound = 0, selectionSound = 0;


    /**
     * This arrays carry coordinates for notable points namely the corners of the board cells,
     * being used to draw on the canvas.
     */
    public int[] xCoordinates = new int[7], yCoordinates = new int[7];

    /**
     * Paints are initialized at ini. They are used to paint background, lines and selection,
     * and also to allow drawing of the bitmaps.
     */
    Paint backgroundPaint = new Paint(), linesPaint = new Paint(), piecesPaint = new Paint(),
            eatersPaint = new Paint(), selectedPaint = new Paint();

    /**
     * Used during calculations at onDraw.
     */
    public int boardSide;

    //bitmaps:
    public Bitmap blueCake = BitmapFactory.decodeResource(getResources(), R.drawable.blue_cake);
    public Bitmap redCake = BitmapFactory.decodeResource(getResources(), R.drawable.red_cake);
    public Bitmap whiteCake = BitmapFactory.decodeResource(getResources(), R.drawable.white_cake);
    public Bitmap yellowCake = BitmapFactory.decodeResource(getResources(), R.drawable.yellow_cake);
    public Bitmap greenCake = BitmapFactory.decodeResource(getResources(), R.drawable.green_cake);

    public Bitmap blueEater = BitmapFactory.decodeResource(getResources(), R.drawable.blue_eater);
    public Bitmap redEater = BitmapFactory.decodeResource(getResources(), R.drawable.red_eater);
    public Bitmap whiteEater = BitmapFactory.decodeResource(getResources(), R.drawable.white_eater);
    public Bitmap yellowEater = BitmapFactory.decodeResource(getResources(), R.drawable.yellow_eater);
    public Bitmap greenEater = BitmapFactory.decodeResource(getResources(), R.drawable.green_eater);


    /**
     * All constructors set the activity field with the context and cal ini.
     * @param context The GameActivity.
     */
    public GameView(Context context) {
        super(context);
        activity = (GameActivity)context;
        ini();
    }
    public GameView(Context context, AttributeSet attrs) {
        super(context, attrs);
        activity = (GameActivity)context;
        ini();
    }
    public GameView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        activity = (GameActivity)context;
        ini();
    }

    /**
     * Initializer.
     * Sets the paints and the SoundPool
     */
    @SuppressWarnings("deprecation")
    public void ini(){
        // Initializes the paints.
        backgroundPaint.setColor(Color.BLACK);
        backgroundPaint.setStyle(Paint.Style.FILL_AND_STROKE);
        linesPaint.setColor(Color.WHITE);
        linesPaint.setStyle(Paint.Style.FILL_AND_STROKE);
        piecesPaint.setStyle(Paint.Style.FILL_AND_STROKE);
        eatersPaint.setStyle(Paint.Style.FILL_AND_STROKE);
        selectedPaint.setColor(Color.GRAY);
        selectedPaint.setStyle(Paint.Style.FILL_AND_STROKE);

        // Sets the tracks on the SoundPool.
        soundPool = new SoundPool(4, AudioManager.STREAM_MUSIC, 100);
        eatSound = soundPool.load(activity, R.raw.eatingsound, 1);
        movingSound = soundPool.load(activity, R.raw.movesound, 1);
        selectionSound = soundPool.load(activity, R.raw.selectionsound, 1);
    }

    /**
     * Handles the touch; it can select, deselect, move - eat - test the end of the game.
     *
     * Internally divided into these 8 parts:
     * 1:
     * Continues only if action is down and if no animation is running.
     * 2:
     * Checks if touch happened on a cell and sets touchX and touchY. Ends if touch didn't happen on a cell.
     * 3:
     * If no cell is selected, it selects cell if it has something, calls for invalidate() and then ends.
     * 4:
     * If the touched cell isn't next to the selected cell it deselects the selection, calls invalidate() and then ends.
     * 5:
     * Prepares the movement and testing by putting all the pieces on a board which is a 2-dimensional array.
     * Deselects selected cell and decrements the number of moves.
     * 6:
     * Checks touched cell to decide if there will be a swap or a move, puts the information needed for the animation,
     * sets inSwapping or inMove true and performs that operation on the board
     * so that the testing for eating has the pieces in the right place.
     * 7:
     * If there are pieces in position to be eaten sets needDelete, and leaves those pieces with toDelete = true
     * and destinyX and DestinyY with coordinates of their eater.
     * 8:
     * Tests for game over either by wining or losing, setting gonnaWin or gonnaLose true accordingly.
     * Plays move or eat sound.
     * Invalidates the only time since moving or swapping pieces was decided.
     *
     * Sounds:
     * At ...
     *
     * @param event The event from which to get the touched cell.
     * @return True always.
     */
    @Override
    public boolean onTouchEvent(@NonNull MotionEvent event){

        // 1
        // Continues only if action down and if no animation is running.
        if(event.getAction()!= MotionEvent.ACTION_DOWN || inEating || inSwapping || inMove) return true;

        // 2
        // Checks if touch happened on a cell and sets touchX and touchY.
        // Ends if touch didn't happen on a cell.
        Boolean touchOnCell = false;
        int touchedX = 0, touchedY = 0;
        for(int testX = 0; testX < 6; testX++){
            for(int testY = 0; testY < 6; testY++){
                if(event.getX() > xCoordinates[testX] && event.getX() < xCoordinates[testX+1] && event.getY() > yCoordinates[testY] && event.getY() < yCoordinates[testY+1]){
                    touchedX = testX;  touchedY = testY;   touchOnCell = true;
                }
            }
        }
        if(!touchOnCell) return true;

        // 3
        // If no cell is selected, it selects cell if it has something, calls for invalidate()
        // and then ends.
        if (!hasSelected){
            boolean has = false;
            for(BoardPiece piece : Pieces){
                if(piece.boardX == touchedX && piece.boardY == touchedY) has = true;
            }
            if(has) {                                   // If there was a piece in the selected cell.
                hasSelected = true;                     // selects it and invalidates.
                selectedX = touchedX;
                selectedY = touchedY;
                invalidate(); //beginning

                // Selection sound plays now.
                if (soundOn) {
                    AudioManager audioManager = (AudioManager) activity.getSystemService(Context.AUDIO_SERVICE);
                    float curVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
                    float maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                    soundPool.play(selectionSound, curVolume / maxVolume, curVolume / maxVolume, 1, 0, 1F);
                }
            }
            return true;                                // Ends touch event handling.
        }

        // 4
        // If the touched cell was not next to the touched cell it deselects the selection, calls
        // invalidate() and then ends.
        if (!((selectedX == touchedX && (selectedY == touchedY-1 || selectedY == touchedY+1))||(selectedY == touchedY && (selectedX == touchedX+1 || selectedX == touchedX-1)))){
            hasSelected = false;
            invalidate();

            // Selection sound plays now.
            if (soundOn) {
                AudioManager audioManager = (AudioManager) activity.getSystemService(Context.AUDIO_SERVICE);
                float curVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
                float maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                soundPool.play(selectionSound, curVolume / maxVolume, curVolume / maxVolume, 1, 0, 1F);
            }

            return true;                        // Ends touch event.
        }

        // 5
        // Prepares the movement and testing by putting all the pieces on a board which is a 2-dimensional
        // array.
        // Deselects selected cell and decrements the number of moves.
        BoardPiece[][] board = new BoardPiece[6][6];
        for(BoardPiece piece : Pieces){
            board[piece.boardX][piece.boardY] = piece;
            piece.toDelete = false;
            piece.wasTested = false;
        }
        hasSelected = false;
        movesLeft--;
        activity.changeMoves(movesLeft);

        // 6
        // Checks touched cell to decide if there will be a swap or a move, puts the information
        // needed for the animation, sets inSwapping or inMove true and performs that operation on the board
        // so that the testing for eating has the pieces in the right place.
        if (board[touchedX][touchedY] != null){
            piece1 = board[touchedX][touchedY];
            piece2 = board[selectedX][selectedY];
            piece1.boardX = selectedX;
            piece1.boardY = selectedY;
            piece2.boardX = touchedX;
            piece2.boardY = touchedY;
            board[touchedX][touchedY] = piece2;
            board[selectedX][selectedY] = piece1;
            if (piece1.floatX > piece2.floatX){
                piece1XMovement = (piece1.floatX - piece2.floatX) / -10;
                piece2XMovement = (piece1.floatX - piece2.floatX) / 10;
            } else {
                piece2XMovement = (piece2.floatX - piece1.floatX) / -10;
                piece1XMovement = (piece2.floatX - piece1.floatX) / 10;
            }
            if (piece1.floatY > piece2.floatY){
                piece1YMovement = (piece1.floatY - piece2.floatY) / -10;
                piece2YMovement = (piece1.floatY - piece2.floatY) / 10;
            } else {
                piece2YMovement = (piece2.floatY - piece1.floatY) / -10;
                piece1YMovement = (piece2.floatY - piece1.floatY) / 10;
            }
            frame = 0;
            inSwapping = true;

        } else {
            piece1 = board[selectedX][selectedY];
            piece1.boardX = touchedX;
            piece1.boardY = touchedY;
            board[touchedX][touchedY] = board[selectedX][selectedY];
            board[selectedX][selectedY] = null;
            float xOfDestiny = (100F / 6F) * touchedX;
            float yOfDestiny = (100F / 6F) * touchedY;
            if (xOfDestiny > piece1.floatX) piece1XMovement = (xOfDestiny - piece1.floatX) /10;
            else piece1XMovement = (piece1.floatX - xOfDestiny) / -10;
            if (yOfDestiny > piece1.floatY) piece1YMovement = (yOfDestiny - piece1.floatY) / 10;
            else piece1YMovement = (piece1.floatY - yOfDestiny) / -10;
            frame = 0;
            inMove = true;
        }


        // 7
        // If there are pieces in position to be eaten sets needDelete, and leaves those pieces with toDelete = true
        // and destinyX and DestinyY with coordinates of their eater.

        // All eaters are set toDelete = true and their destinyX and destinyY are set to their coordinates.
        // This way as they propagate the information and the pieces will now where their eater is so that the
        // eat animation works.
        for(BoardPiece p : Pieces){
            if(p.isEater){
                p.toDelete = true;
                p.eater = p;

            }
        }

        // yetToTest has the number of untested pieces to allow break from test if all pieces have been tested.
        int yetToTest = Pieces.size();

        // Creates BoardPiece variable to hold the one being tested.
        BoardPiece pieceBeingTested;

        // Maximum 36 times, to assure propagation to all cells.
        for(int index =0; index < 36; index++ ){

            // Checks all pieces, making them toDelete = true if they are going to be eaten.
            for (BoardPiece pieceDoingTheTest : Pieces){
                if (!pieceDoingTheTest.wasTested) {
                    if (pieceDoingTheTest.toDelete) {

                        // IF the position exists, and if it has a piece,
                        // and if it is the same color, and if it wasn't yet marked as toDelete
                        // THEN sets toDelete = true and sets the eater of the piece being tested
                        // the same as the eater of the piece doing the test.
                        if (pieceDoingTheTest.boardX > 0 && board[pieceDoingTheTest.boardX - 1][pieceDoingTheTest.boardY]!=null && board[pieceDoingTheTest.boardX - 1][pieceDoingTheTest.boardY].pieceColor == pieceDoingTheTest.pieceColor && !board[pieceDoingTheTest.boardX - 1][pieceDoingTheTest.boardY].toDelete) {
                            pieceBeingTested = board[pieceDoingTheTest.boardX - 1][pieceDoingTheTest.boardY]; pieceBeingTested.toDelete = true; pieceBeingTested.eater = pieceDoingTheTest.eater;}
                        if (pieceDoingTheTest.boardX < 5 && board[pieceDoingTheTest.boardX + 1][pieceDoingTheTest.boardY]!=null && board[pieceDoingTheTest.boardX + 1][pieceDoingTheTest.boardY].pieceColor == pieceDoingTheTest.pieceColor && !board[pieceDoingTheTest.boardX + 1][pieceDoingTheTest.boardY].toDelete) {
                            pieceBeingTested = board[pieceDoingTheTest.boardX + 1][pieceDoingTheTest.boardY]; pieceBeingTested.toDelete = true; pieceBeingTested.eater = pieceDoingTheTest.eater;}
                        if (pieceDoingTheTest.boardY > 0 && board[pieceDoingTheTest.boardX][pieceDoingTheTest.boardY - 1]!=null && board[pieceDoingTheTest.boardX][pieceDoingTheTest.boardY - 1].pieceColor == pieceDoingTheTest.pieceColor && !board[pieceDoingTheTest.boardX][pieceDoingTheTest.boardY - 1].toDelete) {
                            pieceBeingTested = board[pieceDoingTheTest.boardX][pieceDoingTheTest.boardY - 1]; pieceBeingTested.toDelete = true; pieceBeingTested.eater = pieceDoingTheTest.eater;}
                        if (pieceDoingTheTest.boardY < 5 && board[pieceDoingTheTest.boardX][pieceDoingTheTest.boardY + 1]!=null && board[pieceDoingTheTest.boardX][pieceDoingTheTest.boardY + 1].pieceColor == pieceDoingTheTest.pieceColor && !board[pieceDoingTheTest.boardX][pieceDoingTheTest.boardY + 1].toDelete) {
                            pieceBeingTested = board[pieceDoingTheTest.boardX][pieceDoingTheTest.boardY + 1]; pieceBeingTested.toDelete = true; pieceBeingTested.eater = pieceDoingTheTest.eater;}

                        pieceDoingTheTest.wasTested = true;
                        yetToTest -- ;
                    }
                }
            }
            if (yetToTest == 0) break; // If there are no more pieces to be tested, leaves the loop.
        }

        // Removes toDelete from the eaters, sets needDelete true if there is something to eat
        // and false if there isn't.
        needDelete = false;
        for(BoardPiece piece : Pieces){
            if(piece.isEater) piece.toDelete =  false;
            else if (piece.toDelete) needDelete = true;
        }

        // 8
        // Tests for game over either by wining or losing, setting gonnaWin or gonnaLose true accordingly.
        // Plays move or eat sound.
        // Invalidates the only time since moving or swapping pieces was decided.
        boolean zeroFood = true;
        for(BoardPiece p : Pieces) if(!p.isEater && !p.toDelete)zeroFood = false;
        if(zeroFood) gonnaWin = true;
        else if(movesLeft < 1) gonnaLose = true;

        if (soundOn) {
            AudioManager audioManager = (AudioManager) activity.getSystemService(Context.AUDIO_SERVICE);
            float curVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
            float maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
            if (needDelete)
                soundPool.play(eatSound, curVolume / maxVolume, curVolume / maxVolume, 1, 0, 1F);
            else
                soundPool.play(movingSound, curVolume / maxVolume, curVolume / maxVolume, 1, 0, 1F);
        }

        invalidate();

        return true;
    }


    /**
     * If there's an animation going on, has to change the position of the pieces, change the
     * current frame, and set to invalidate again.
     * If it's the last frame of move or swap animation, and needDelete = true,
     * has to prepare pieces to delete and set the eating animation going.
     * If it's the last frame of eating animation has to delete pieces to delete and invalidate
     * once more to show the board without those pieces.
     * At the last frame of any animation, it resets the frame, and sets the animation field
     * false.
     * This animation processing only happens if animationOn == true, else the pieces are set
     * to final destination immediately and if necessary the deletion happens right then.
     *
     * After taking care of the animation, draws the board:
     * 1: Checks the canvas orientation, decides the boardSide and sets the offset on either
     * width or height.
     * 2: Sets the cells coordinates, draws background, selection indicator and lines.
     * 3: Draws the pieces using switch to decide which bitmap to use.
     * 4: Invalidates in case it's still on an animation, if not and if set to win or lose calls
     * activity to do that.
     *
     * A scale has to be calculated to determine the conversion from the pieces float coordinates
     * that go from 0 to 100 to the actual coordinates on the board, to which the offset (distance
     * from the beginning of the canvas to the board) has to be added.
     *
     * @param canvas The canvas on which the board will be drawn.
     *
     */
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        boolean needsRedraw = false;


        if(inSwapping && animationOn){
            piece1.floatX += piece1XMovement;
            piece1.floatY += piece1YMovement;
            piece2.floatX += piece2XMovement;
            piece2.floatY += piece2YMovement;
            frame ++;
            if (frame > 9)
            {
                inSwapping = false;
                if (needDelete){
                    inEating = true;
                    prepareEatingOfPieces();
                }
                frame = 1;
            }
            needsRedraw = true;
        }
        if(inMove && animationOn){
            piece1.floatX += piece1XMovement;
            piece1.floatY += piece1YMovement;
            frame ++;
            if (frame > 9){
                inMove = false;
                if (needDelete){
                    inEating = true;
                    prepareEatingOfPieces();
                }
                frame = 1;
            }
            needsRedraw = true;
        }
        if (inEating && animationOn){
            for (BoardPiece piece : Pieces){
                if (piece.toDelete){
                    piece.floatX += piece.destinyX;
                    piece.floatY += piece.destinyY;
                }
            }
            frame++;
            if(frame > 10) {
                inEating = false;
                frame = 1;
                removeDeletedPieces();
                needDelete = false;
            }
            needsRedraw = true;

        }

        if ((inMove || inSwapping) && !animationOn){
            if (needDelete) removeDeletedPieces();
            for (BoardPiece pie : Pieces) {
                pie.stick();
            }
            inMove = false;
            inSwapping = false;
            needDelete = false;
            needsRedraw = false;
        }

        if(!inSwapping && !inMove && !inEating){
            for (BoardPiece pie : Pieces) {
                pie.stick();
            }
        }


        //GETTING THE DIMENSIONS//////
        //the smallest canvas dimension will go to the boardSide and the first
        //coordinate of the other dimension will get the proper offset
        if(canvas.getHeight() < canvas.getWidth()) {
            boardSide = canvas.getHeight();
            xCoordinates[0]=(canvas.getWidth()-boardSide)/2;
            yCoordinates[0]=0;
        }
        else {
            boardSide = canvas.getWidth();
            xCoordinates[0]=0;
            yCoordinates[0]=(canvas.getHeight()-boardSide)/2;
        }
        //all of the other dimensions are set (boardSide / 6) apart
        for(int index = 1; index < 7; index++){
            xCoordinates[index] = xCoordinates[index-1] + (boardSide/6);
            yCoordinates[index] = yCoordinates[index-1] + (boardSide/6);
        }


        //DRAW THE BACKGROUND////
        canvas.drawRect(xCoordinates[0], yCoordinates[0], xCoordinates[0] + boardSide, yCoordinates[0] + boardSide, backgroundPaint);

        //DRAW THE SELECTION SHADE///
        if(hasSelected){
            canvas.drawRect((float) xCoordinates[selectedX], (float) yCoordinates[selectedY], (float) xCoordinates[selectedX + 1], (float) yCoordinates[selectedY + 1], selectedPaint);
        }

        //DRAW THE LINES///
        for(int index = 1; index < 6 ; index++){
            canvas.drawLine(xCoordinates[index], yCoordinates[0], xCoordinates[index], yCoordinates[6], linesPaint);
            canvas.drawLine(xCoordinates[0], yCoordinates[index], xCoordinates[6], yCoordinates[index], linesPaint);
        }


        //DRAW THE PIECES////
        /*
        The pieces have int board coordinates and float canvas coordinates
        This is so that animations with the pieces can be done, with them temporarily between board cells
        The canvas coordinates are the ones used to draw
        But, as the canvas can change, they are set in percentage, as if the board was 100*100 in length
        So, a scale is needed, it is what we have to multiply to get from percentage to real canvas width and height
         */
        //gets the size of the pieces
        float side = (float)boardSide / 6F;
        //gets the scale ( 0->100 * scale = 0->canvas_size )
        float scale = (float)boardSide/ 100F;



        for(BoardPiece pie : Pieces){

            Bitmap b;

            if(pie.pieceColor == Color.GREEN){
                if(pie.isEater){
                    b = greenEater;
                }else{
                    b = greenCake;
                }
            } else if(pie.pieceColor == Color.BLUE) { //no switch here because of break and the loop
                if(pie.isEater){
                    b = blueEater;
                }else{
                    b = blueCake;
                }
            } else if(pie.pieceColor == Color.WHITE) {
                if(pie.isEater){
                    b = whiteEater;
                }else{
                    b = whiteCake;
                }
            }else if(pie.pieceColor == Color.YELLOW){
                if(pie.isEater){
                    b = yellowEater;
                }else{
                    b = yellowCake;
                }
            }else {
                if (pie.isEater) {
                    b = redEater;
                } else {
                    b = redCake;
                }
            }
            //Gives the coordinates for the four corners of the piece's bitmap
            int left = xCoordinates[0] + (int)(scale * pie.floatX);
            int top = yCoordinates[0] + (int)(scale * pie.floatY);
            int right = left+(int)side;
            int bottom = top+(int)side;
            //If its a cake, decreases a little
            if(!pie.isEater){
                left+=10;
                top+=10;
                right-=10;
                bottom-=10;
            }
            //Creates the bitmap rectangle
            Rect r = new Rect(left, top, right, bottom);
            //Finally draws the piece!
            canvas.drawBitmap(b, null, r, null);
        }//and repeat


        if (needsRedraw){
            invalidate();
        } else if (gonnaWin){
            activity.win();
        }
          else if (gonnaLose){
            activity.lose();
        }
    }

    public void removeDeletedPieces(){
        ArrayList<BoardPiece> deleter = new ArrayList<>();
        for (BoardPiece piece : Pieces){
            if (piece.toDelete) deleter.add(piece);
        }
        for (BoardPiece p : deleter) {
            Pieces.remove(p);
        }
    }

    public void prepareEatingOfPieces(){
        for (BoardPiece piece : Pieces){
            if (piece.toDelete){
                if (piece.floatX < piece.eater.floatX) piece.destinyX = (piece.eater.floatX - piece.floatX) / 10;
                else piece.destinyX = (piece.floatX - piece.eater.floatX) / -10;
                if (piece.floatY < piece.eater.floatY) piece.destinyY = (piece.eater.floatY - piece.floatY) / 10;
                else piece.destinyY = (piece.floatY - piece.eater.floatY) / -10;
            }
        }

    }
}
