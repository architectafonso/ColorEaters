package com.empire_of_science.joao.coloreaters2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.preference.PreferenceManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

/**
 * Level selection menu.
 */
public class LevelMenuActivity extends AppCompatActivity {

    /**
     *  The game package from which the user will chose the levels.
     *  Transmitted from the package selected activity or from the game, win or lose activities
     *  when back is pressed.
     */
    public int Package;


    /**
     * Gets the Package from Intent or Bundle.
     * Sets the color of buttons in accordance with they having been beaten.
     * If no game package history for this package is found on shared preferences, creates it.
     *
     * @param savedInstanceState Contains the package.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_level_menu);

        // Gets the level package.
        if (savedInstanceState != null){
            Package = savedInstanceState.getInt("levelPackage", 1);
        }else{
            Package = getIntent().getIntExtra("levelPackage", 1);
        }
        setTitle(getResources().getString(R.string.level_package) + " " + Package);

        // Gets the game solving history.
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(this);
        String beatenLevels = pref.getString(String.valueOf(Package), " ");
        // If there is no info for this package, creates it.
        if (beatenLevels.equals(" ")){
            pref.edit().putString(String.valueOf(Package), "nnnnnnnnnnnnnnnnnnnn").apply();
            beatenLevels = "nnnnnnnnnnnnnnnnnnnn";
        }

        // Changes the buttons text color.
        for (int x = 1; x <= 20; x++){
            int id = getResources().getIdentifier("level_"+ (x), "id", getPackageName());
            Button button = (Button)findViewById(id);
            if (beatenLevels.charAt(x-1) == 'n') button.setTextColor(Color.RED);
            else button.setTextColor(Color.rgb(0, 140, 0));
        }
    }


    /**
     * Saves the game package for reconstruction.
     *
     * @param saveInstanceState Has to get levelPackage.
     */
    @Override
    public void onSaveInstanceState(Bundle saveInstanceState){
        saveInstanceState.putInt("levelPackage", Package);
    }


    /**
     * Called when a level button is pressed.
     * Gets the level from the button text and starts GameActivity, sending in the intent
     * the right levelPackage and level.
     *
     * @param view Pressed Button.
     */
    public void startGame(View view){
        Intent intent = new Intent(this, GameActivity.class);
        Button pressedButton = (Button)view;
        int levelInt = Integer.parseInt(pressedButton.getText().toString());
        intent.putExtra("level", levelInt);
        intent.putExtra("levelPackage", Package);
        startActivity(intent);
    }


    /**
     * Pressing back goes to MainLevelMenuActivity where another game package can be selected
     * or go to the main menu.
     */
    @Override
    public void onBackPressed() {
        Intent intent = new Intent(this, MainLevelMenuActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

}
