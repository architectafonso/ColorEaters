package com.empire_of_science.joao.coloreaters2;

import android.graphics.Color;
import java.util.ArrayList;

/**
 * Contains methods that return the pieces of a level and the number of moves of a level.
 * To add a new level package with 20 levels create a new class called Levels_X like the ones
 * that already exist, change the methods getLevel and get number of moves adding a new case
 * and change the layout of the MainLevelMenuActivity to include a new button.
 * Created by João on 17/08/2015.
 */
public class Levels {

    /**
     * This method calls the level package to obtain the level and GetTheLevel to convert it.
     * Each Levels_x class is a game package.
     * @param levelPackage Group of 20 levels chosen by the user.
     * @param level Level to be returned.
     * @return BoardPiece ArrayList with all the pieces of the level.
     */
    public static ArrayList<BoardPiece> getLevel(int levelPackage, int level){
        switch(levelPackage){
            case 1:
                return GetTheLevel(Levels_1.getLevel(level));
            case 2:
                return GetTheLevel(Levels_2.getLevel(level));
            case 3:
                return GetTheLevel(Levels_3.getLevel(level));
            case 4:
                return GetTheLevel(Levels_4.getLevel(level));
            case 5:
                return GetTheLevel(Levels_5.getLevel(level));
            case 6:
                return GetTheLevel(Levels_6.getLevel(level));
            default:
                return new ArrayList<>();
        }
    }

    /**
     * Calls level package class Levels_x for the level.
     * Calls GetTheNumberOfMoves to get the number of moves from the String array.
     * @param levelPackage The package of 20 levels chosen by the user.
     * @param level Chosen level.
     * @return The number of moves that the level has to be solved in.
     */
    public int getNumberOfMoves(int levelPackage, int level){
        switch(levelPackage){
            case 1:
                return GetTheNumberOfMoves(Levels_1.getLevel(level));
            case 2:
                return GetTheNumberOfMoves(Levels_2.getLevel(level));
            case 3:
                return GetTheNumberOfMoves(Levels_3.getLevel(level));
            case 4:
                return GetTheNumberOfMoves(Levels_4.getLevel(level));
            case 5:
                return GetTheNumberOfMoves(Levels_5.getLevel(level));
            case 6:
                return GetTheNumberOfMoves(Levels_6.getLevel(level));
            default:
                return 0;
        }
    }

    /**
     * This method returns the proper BoardPiece ArrayList that forms a level from the string
     * array that allows making the levels in a friendly way.
      * @param input String array representing the level.
     * @return The level's BoardPiece array.
     * @throws RuntimeException in case array isn't in proper format.
     */
    public static ArrayList<BoardPiece> GetTheLevel(String[] input){

        //Checks the format and throws exceptions (for debugging)
        if (input.length != 7) throw (new RuntimeException("Provided Level Isn't in correct form - number of strings"));

        for (int x = 0; x < 6; x++) {
            if (input[x].length() != 6) throw (new RuntimeException("Provided Level Isn't in correct form - wrong string: " + x));
        }

        //Create list for the BoardPeices
        ArrayList<BoardPiece> boardPieceList = new ArrayList<>();

        //Foreach character in the Level String[]
        for (int x = 0; x < 6; x++){
            for (int y = 0; y < 6; y++){

                //Adds new corresponding BoardPiece to the list if there's a letter
                // or nothing if there's a space
                switch (input[y].charAt(x)){
                    case 'b':
                        boardPieceList.add(new BoardPiece(x,y, Color.BLUE, false));
                        break;
                    case 'B':
                        boardPieceList.add(new BoardPiece(x,y, Color.BLUE, true));
                        break;
                    case 'g':
                        boardPieceList.add(new BoardPiece(x,y, Color.GREEN, false));
                        break;
                    case 'G':
                        boardPieceList.add(new BoardPiece(x,y, Color.GREEN, true));
                        break;
                    case 'r':
                        boardPieceList.add(new BoardPiece(x,y, Color.RED, false));
                        break;
                    case 'R':
                        boardPieceList.add(new BoardPiece(x,y, Color.RED, true));
                        break;
                    case 'y':
                        boardPieceList.add(new BoardPiece(x,y, Color.YELLOW, false));
                        break;
                    case 'Y':
                        boardPieceList.add(new BoardPiece(x,y, Color.YELLOW, true));
                        break;
                    case 'w':
                        boardPieceList.add(new BoardPiece(x,y, Color.WHITE, false));
                        break;
                    case 'W':
                        boardPieceList.add(new BoardPiece(x,y, Color.WHITE, true));
                        break;
                    case ' ':
                        break;
                    default: throw (new RuntimeException("Provided Level Isn't in correct form - Bad character"));

                }
            }
        }
        return boardPieceList;
    }

    /**
     * Gets the number of moves of the level from its String[]
     * Doesn't throw an error because it's called after GetTheLevel on the same array,
     * and that method checks the string array format.
     * @param input String[] of the level.
     * @return Number of moves the player has to solve the level.
     */
    public int GetTheNumberOfMoves(String[] input){
        return Integer.parseInt(input[6]);
    }


}