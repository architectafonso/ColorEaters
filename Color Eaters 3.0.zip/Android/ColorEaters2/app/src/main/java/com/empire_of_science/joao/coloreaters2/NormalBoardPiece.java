package com.empire_of_science.joao.coloreaters2;

/**
 * Created by João on 29/09/2016.
 *
 * Class for pieces that are eaters or cakes.
 */
class NormalBoardPiece extends BoardPiece {



    /**
     * If true, this piece is an eater and not a cake.
     */
    boolean isEater;

    /**
     * Color of this piece. Currently allowed Color.BLUE, Color.GREEN, Color.WHITE,
     * Color.RED and Color.YELLOW.
     */
    int pieceColor;

    /**
     * Constructor. Sets the graphics coordinates from the board coordinates.
     *
     * @param board_x Cell x coordinate.
     * @param board_y Cell y coordinate.
     * @param piece_color Piece's color (green, red, yellow, white or blue).
     * @param is_eater True if eater and false if cake.
     */
    NormalBoardPiece(int board_x, int board_y, int piece_color, boolean is_eater){
        boardX = board_x;
        boardY = board_y;
        graphicsX = (1000/6) * board_x;
        graphicsY = (1000/6) * board_y;
        pieceColor = piece_color;
        isEater = is_eater;
    }

    /**
     * Checks for the pieces around and marks them to be eaten if that is the case.
     * If this piece is set as toDelete == true and wasTested == false, then checks the pieces
     * around and if they are of the same color, sets their toDelete = true, sets their eater
     * = to the one of this piece, and sets wasTested = true.
     * When index == 0, sets toDelete = true if it is an eater, and at index == 37,
     * sets toDelete = false if it is an eater.
     * @param board GameBoard to have access to the other pieces.
     * @param index The stage of the eating process.
     * @return True if some piece was eaten.
     */
    public boolean eat(Board board, int index) {
        // If it is the first stage, sets wasTested as false, and toDelete true only for eaters.
        if (index == 0) {
            wasTested = false;
            if (isEater)  {
                toDelete = true;
                eater = this;
            }
            else toDelete = false;
            return false;
        }

        // If it is the last stage, sets toDelete as false for the eaters.
        if (index == 37) {
            if (isEater) toDelete = false;
            if (toDelete) {
                deltaX = (eater.graphicsX - graphicsX) /10;
                deltaY = (eater.graphicsY - graphicsY) / 10;
            }
            return false;
        }

        // Else, if toDelete == true and wasTested == false, has to test pieces around, if
        // they are normal board pieces with the same color they will be eaten!
        if (!wasTested && toDelete) {
            boolean didEat = false;
            if (testAbove(board)) didEat = true;
            if (testLeft(board)) didEat = true;
            if (testRight(board)) didEat = true ;
            if (testBelow(board)) didEat = true;
            wasTested = true;
            return didEat;
        }
        return false;
    }

    /**
     * When eating, tests the piece on top if it should be eaten.
     * @param board The game board.
     * @return True if there was a piece to eat.
     */
    private boolean testAbove(Board board){
        if (boardY > 0) {
            if (board.pieces[boardX][boardY - 1] != null){
                if (board.pieces[boardX][boardY - 1] instanceof NormalBoardPiece) {
                    NormalBoardPiece p = (NormalBoardPiece)board.pieces[boardX][boardY - 1];
                    if (!p.wasTested && !p.toDelete && p.pieceColor == pieceColor){
                        p.toDelete = true;
                        p.eater = eater;
                        return true;
                    }
                }
            }
        }
        return false;
    }
    /**
    * When eating, tests the piece below if it should be eaten.
    * @param board The game board.
    * @return True if there was a piece to eat.
     */
    private boolean testBelow(Board board) {
        if (boardY < 5) {
            if (board.pieces[boardX][boardY + 1] != null){
                if (board.pieces[boardX][boardY + 1] instanceof NormalBoardPiece) {
                    NormalBoardPiece p = (NormalBoardPiece)board.pieces[boardX][boardY + 1];
                    if (!p.wasTested && !p.toDelete && p.pieceColor == pieceColor){
                        p.toDelete = true;
                        p.eater = eater;
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * When eating, tests the piece at the left if it should be eaten.
     * @param board The game board.
     * @return True if there was a piece to eat.
     */
    private boolean testLeft(Board board) {
        if (boardX > 0) {
            if (board.pieces[boardX - 1][boardY] != null){
                if (board.pieces[boardX - 1][boardY] instanceof NormalBoardPiece) {
                    NormalBoardPiece p = (NormalBoardPiece)board.pieces[boardX - 1][boardY];
                    if (!p.wasTested && !p.toDelete && p.pieceColor == pieceColor){
                        p.toDelete = true;
                        p.eater = eater;
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * When eating, tests the piece at the right if it should be eaten.
     * @param board The game board.
     * @return True if there was a piece to eat.
     */
    private boolean testRight(Board board) {
        if (boardX < 5) {
            if (board.pieces[boardX + 1][boardY] != null){
                if (board.pieces[boardX + 1][boardY] instanceof NormalBoardPiece) {
                    NormalBoardPiece p = (NormalBoardPiece)board.pieces[boardX + 1][boardY];
                    if (!p.wasTested && !p.toDelete && p.pieceColor == pieceColor){
                        p.toDelete = true;
                        p.eater = eater;
                        return true;
                    }
                }
            }
        }
        return false;
    }



}
