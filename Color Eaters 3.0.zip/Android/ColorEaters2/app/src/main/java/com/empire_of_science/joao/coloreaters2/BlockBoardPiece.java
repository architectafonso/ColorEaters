package com.empire_of_science.joao.coloreaters2;

/**
 * Created by João on 30/09/2016.
 * Represents the 'X' pieces that do not move during the game.
 */
class BlockBoardPiece extends BoardPiece {


    /**
     * The constructor sets teh pieces x and y board coordinates.
     * Also sets the graphics coordinates accordingly.
     * @param x Board x coordinate.
     * @param y Board y coordinate.
     */
    BlockBoardPiece(int x, int y){
        boardX = x;
        boardY = y;
        stick();
    }

    /**
     * Method that is part of the eating process.
     * This piece cannot be eaten, so this method always returns false, and sets toDelete as false.
     * @param board The board as context.
     * @param index The step of the eating process.
     * @return Always false.
     */
    public boolean eat(Board board, int index) {
        toDelete = false;
        return false;
    }
}
