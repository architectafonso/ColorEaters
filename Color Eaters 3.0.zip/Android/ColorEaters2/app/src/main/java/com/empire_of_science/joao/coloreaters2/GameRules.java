package com.empire_of_science.joao.coloreaters2;

/**
 * Created by João on 28/09/2016.
 *
 * Contains static methods that are to be changed if the rules of the game change,
 * like if there's a new kind of piece.
 */
class GameRules {

    /**
     * Sets the state of the provided Board to Win if there is no cake, to Lose if there is cake
     * and no more moves, and Continue in any other case.
     * @param board The Board to test for game over.
     */
    static void setGameOverState(Board board) {
        boolean zeroFood = true;
        for(BoardPiece[] array : board.pieces) for(BoardPiece piece : array){
            if(piece instanceof NormalBoardPiece) {
                if (!((NormalBoardPiece) piece).isEater && !piece.toDelete) zeroFood = false;
            }
        }
        if(zeroFood){
            board.state = GameOverState.Win;
        }
        else if(board.movesLeft < 1){
            board.state = GameOverState.Lose;
        }
        else
        {
            board.state = GameOverState.Continue;
        }
    }


    /**
     * This method is used to decide if a movement is valid.
     * Must be changed if a new kind of piece is introduced.
     * Now it allows motion if it is from a NormalBoardPiece to either another one or a blank space,
     * and if it is in a place next door vertically or horizontally.
     * @param board The board containing the pieces and info on the selection.
     * @param touchedX X coordinate of the place the piece should be moved to.
     * @param touchedY Y coordinate of the place the piece should be moved to.
     * @return True if it is a valid motion.
     */
    static boolean testValidMotion(Board board, int touchedX, int touchedY) {
        if (!((board.selectedX == touchedX && (board.selectedY == touchedY-1 || board.selectedY == touchedY+1))
                ||(board.selectedY == touchedY && (board.selectedX == touchedX+1 || board.selectedX == touchedX-1))))
            return false;

        // If the touched piece is an BlockPiece then it doesn't move neither.
        return !(board.pieces[touchedX][touchedY] instanceof BlockBoardPiece);
    }


    /**
     * This method is used to decide if trying to select one piece will work or not.
     * Currently, if it is an normal piece, returns true, in any other case returns false.
     * This method must be changed if a new kind of piece is introduced.
     * @param piece The piece bing tested.
     * @param board The board for context.
     * @return True if the piece can be selected.
     */
    static boolean movable(BoardPiece piece, Board board)
    {
        return piece instanceof NormalBoardPiece;
    }
}
