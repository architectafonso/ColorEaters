package com.empire_of_science.joao.coloreaters2;

/**
 * Created by João on 14/08/2015.
 * This abstract class represents every board piece of any kind.
 */
abstract class BoardPiece {

    /**
     * Board horizontal coordinate for the board cell the piece is in.
     * Will be a value between 0 and 5.
     */
    int boardX;

    /**
     * Board vertical coordinate for the board cell the piece is in.
     * Will be a value between 0 and 5.
     */
    int boardY;

    /**
     * Coordinates for the horizontal precise position of the piece in the view.
     * Used because of animations. Will be a value between 0 and 100.
     */
    int graphicsX;

    /**
     * Coordinates for the vertical precise position of the piece in the view.
     * Used because of animations. Will be a value between 0 and 100.
     */
    int graphicsY;

    /**
     * Set true during a test to check for pieces to be eaten.
     * If it's set true, this piece will be deleted when Board.deletePiecesToDelete() is called.
     */
    boolean toDelete;

    /**
     * Used during test that checks pieces to eat. It is set true when this piece,
     * after being set doDelete = true, has already checked the pieces above, below and to the sides
     * to see if they should be set to be eaten.
     */
    boolean wasTested;

    /**
     * How much the piece should move horizontally per frame to reach the animation destiny.
     */
    int deltaX;

    /**
     * How much the piece should move vertically per frame to reach the animation destiny.
     */
    int deltaY;

    /**
     * Points to the eater of this piece, which is another piece that this piece
     * should follow if it is in an animation for deletion.
     * The reason why there's a reference to the eater first instead of getting the eater's position
     * is that the eater might move during move animation, and then the pieces eaten by it
     * would move to a cell that's empty or with another piece.
     */
    BoardPiece eater;

    /**
     * Makes sure the canvas float coordinates are set in accordance with board position.
     * This allows to make sure that the position is the one of the cell the piece is in after the
     * animations.
     * The graphics coordinates are set with a value between 0 and 1000 and during GameView's onDraw
     * that is converted to the actual canvas coordinates.
     */
    void stick(){
        graphicsX = (1000/6)* boardX;
        graphicsY = (1000/6)* boardY;
    }

    /**
     * Abstract method that defines how each piece will eat the others.
     * It is called 38 times with index between 0 and 37.
     * The first and last steps are for specific actions, and the other 36 steps are to ensure
     * propagation to every single cell.
     * @param board The board for context.
     * @param index The step of the eating process.
     * @return True if some piece was eaten by this one.
     */
    public abstract boolean eat(Board board, int index);
}


